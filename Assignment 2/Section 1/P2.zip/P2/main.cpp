#include <iostream>
#include <cstdlib>
#include <fstream>
#include<vector>
#include<chrono>
#include<ostream>
using namespace std;

void insertionSort(int arr[],  int start,  int end){
    for(int i = 1; i < end; ++i){
        int key = arr[i];
        int j = i;
        while(j >= 1 && arr[j-1] > key){
            arr[j] = arr[j-1];
            j--;
        }
        arr[j] = key;
    }
}

int binarySearch(int arr[],  int start,  int end,  int  val){

    if (end <= start){
        if (val > arr[start]){
            return (start + 1);
        }
        else{
           return  start;
        }
    }


    int mid = (start + end) / 2;

    if (val == arr[mid])
        return mid + 1;

    if (val > arr[mid])
        return binarySearch(arr, mid+1, end, val);
    return binarySearch(arr, start,  mid - 1,val);
}

void insertionSortBS(int arr[],int size){
    int val,location;

    for(int i = 1; i < size; ++i){
         val = arr[i];
         int j = i -1;
        location  = binarySearch(arr,0,j,val);
        while(j >= location){
            arr[j+1] = arr[j];
            j--;
        }
        arr[j+1] = val;

    }
}

//create 2 arrays to store time of each algorithm for each size
double Insertion [20],InsertionWithBS[20];
int main() {

    int index = 0;
    srand(time(0));

    for(int i = 5000; i <= 100000; i += 5000){
        int MAX_SIZE = i;
        //creat 3 arrays with the same size to hold the same data
        int nums1[MAX_SIZE],  nums2[MAX_SIZE];

        for(int j = 0 ; j < MAX_SIZE; ++j){
            nums1[j] = rand();
            nums2[j] = nums1[j];

        }

        double elapsed_time;
       // measure merge sort performance
        double start = clock();  //calculate start time
        insertionSort(nums1,0,MAX_SIZE);
        double end = clock();  //calculate end time
        elapsed_time = double(end-start) / CLOCKS_PER_SEC; // calculate total time
        Insertion[index] = elapsed_time;//store the result

        // measure quick sort using end pivot  performance
        start = clock();//calculate start time
        insertionSortBS(nums2,MAX_SIZE-1);
        end = clock();//calculate end time
        elapsed_time = double(end-start) / CLOCKS_PER_SEC;// calculate total time
        InsertionWithBS[index] = elapsed_time;//store the result

        index++;//store the result
    }

    //write the results to a file
    ofstream myFile;
    myFile.open("results.txt");
    if(myFile.is_open()){
        myFile<<"Size"<<"\t"<<"Inseration"<<"\t"<<"InserationWithBS"<<"\t\t\n";

        for(int i = 0, SIZE = 5000 ; i < 20 ; ++i, SIZE+=5000){
            myFile<<SIZE<<"\t"<<Insertion[i]<<"sec"<<"\t"<<InsertionWithBS[i]<<"sec\n";
        }
    }

    myFile.close();
    system("pause");
    return 0;
}










